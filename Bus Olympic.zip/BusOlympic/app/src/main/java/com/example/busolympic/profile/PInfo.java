package com.example.busolympic.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.busolympic.Bookingfragment;
import com.example.busolympic.BusEvents.BusTimeTableHome;
import com.example.busolympic.Profilefragment;
import com.example.busolympic.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class PInfo extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_p_info, container, false);
        Profile profile = Method.loadProfile(getContext());
        TextView userID = (TextView) view.findViewById(R.id.username);
        TextView cardNo = (TextView) view.findViewById(R.id.card);
        TextView password = (TextView) view.findViewById(R.id.password);
        Button logout = view.findViewById(R.id.logout);

        userID.setText(profile.getUserID());
        password.setText(profile.getPassword());
        cardNo.setText(profile.getCardNumber());
        
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment newFragment = new Profilefragment();
                Toast.makeText(getActivity(),"Logout Successful", Toast.LENGTH_SHORT).show();
                Method.clearProfile(getContext());
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, newFragment);
                transaction.commit();
            }
        });

        return view;
    }


}
