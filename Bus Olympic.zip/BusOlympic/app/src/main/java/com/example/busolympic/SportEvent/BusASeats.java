package com.example.busolympic.SportEvent;

import android.app.AlertDialog;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.busolympic.BusEvents.BusDetail;
import com.example.busolympic.R;
import com.example.busolympic.profile.PLogin;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class BusASeats extends Fragment {
    @Nullable
    public int ischeckbox(CheckBox x){
        int y=0;
        if(x.isChecked()){
            y++;
        }
        return y;
    }
    public  int isover(ArrayList<CheckBox> x){
        int y=0;
        for(CheckBox a : x){
            y+=ischeckbox(a);
        }
        return  y;
    }
    private RecyclerView recyclerView;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.bus_a, container, false);
        recyclerView=v.findViewById(R.id.event_list_recyclerview);
        Button book = v.findViewById(R.id.book);
        final CheckBox a11 = v.findViewById(R.id.B11);
        final CheckBox a12 = v.findViewById(R.id.A12);
        final CheckBox a13 = v.findViewById(R.id.A13);
        final CheckBox a14 = v.findViewById(R.id.A14);
        final CheckBox a15 = v.findViewById(R.id.A15);
        final CheckBox a21 = v.findViewById(R.id.A21);
        final CheckBox a22 = v.findViewById(R.id.A22);
        final CheckBox a23 = v.findViewById(R.id.A23);
        final CheckBox a24 = v.findViewById(R.id.A24);
        final CheckBox a25 = v.findViewById(R.id.A25);
        final CheckBox a31 = v.findViewById(R.id.A31);
        final CheckBox a32 = v.findViewById(R.id.A32);
        final CheckBox a33 = v.findViewById(R.id.A33);
        final CheckBox a34 = v.findViewById(R.id.A34);
        final CheckBox a35 = v.findViewById(R.id.A35);
        final CheckBox a41 = v.findViewById(R.id.A41);
        final CheckBox a42 = v.findViewById(R.id.A42);
        final CheckBox a43 = v.findViewById(R.id.A43);
        final CheckBox a44 = v.findViewById(R.id.A44);
        final CheckBox a45 = v.findViewById(R.id.A45);
        final ArrayList<CheckBox> seat = new ArrayList<CheckBox>();
        final ArrayList<CheckBox> yourseat = new ArrayList<CheckBox>();
        seat.add(a11);
        seat.add(a12);
        seat.add(a13);
        seat.add(a14);
        seat.add(a15);
        seat.add(a21);
        seat.add(a22);
        seat.add(a23);
        seat.add(a24);
        seat.add(a25);
        seat.add(a31);
        seat.add(a32);
        seat.add(a33);
        seat.add(a34);
        seat.add(a35);
        seat.add(a41);
        seat.add(a42);
        seat.add(a43);
        seat.add(a44);
        seat.add(a45);

        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileInputStream fis = null;
                String output = "";
                Context context = null;

                try {
                    fis = context.openFileInput("IsLogintxt");
                    InputStreamReader isr = new InputStreamReader(fis);
                    BufferedReader br = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    String text;

                    while ((text = br.readLine()) != null) {
                        sb.append(text);
                    }

                    output = sb.toString();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (fis != null) {
                        try {
                            fis.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if(output == "true"){
                    if(a11.isChecked() == false || a12.isChecked() == false || a13.isChecked() == false || a14.isChecked() == false || a15.isChecked() == false || a21.isChecked() == false ||
                            a22.isChecked() == false || a23.isChecked() == false || a24.isChecked() == false || a25.isChecked() == false || a31.isChecked() == false || a32.isChecked() == false ||
                            a33.isChecked() == false || a34.isChecked() == false || a35.isChecked() == false || a41.isChecked() == false || a42.isChecked() == false || a43.isChecked() == false || a44.isChecked() == false || a45.isChecked() == false) {
                        Toast.makeText(getActivity(),"please select a seats",Toast.LENGTH_SHORT).show();
                    }else if (isover(seat)>2){
                        Toast.makeText(getActivity(),"over booking",Toast.LENGTH_SHORT).show();
                    }else {
                        if (a11.isChecked() == true) {
                            a11.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a11);
                        }
                        if (a12.isChecked() == true) {
                            a12.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a12);
                        }
                        if (a13.isChecked() == true) {
                            a13.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a13);
                        }
                        if (a14.isChecked() == true) {
                            a14.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a14);
                        }
                        if (a15.isChecked() == true) {
                            a15.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a15);
                        }
                        if (a21.isChecked() == true) {
                            a21.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a21);
                        }
                        if (a22.isChecked() == true) {
                            a22.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a22);
                        }
                        if (a23.isChecked() == true) {
                            a23.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a23);
                        }
                        if (a24.isChecked() == true) {
                            a24.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a24);
                        }
                        if (a25.isChecked() == true) {
                            a25.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a25);
                        }
                        if (a31.isChecked() == true) {
                            a31.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a31);
                        }
                        if (a32.isChecked() == true) {
                            a32.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a32);
                        }
                        if (a33.isChecked() == true) {
                            a33.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a33);
                        }
                        if (a34.isChecked() == true) {
                            a34.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a34);
                        }
                        if (a35.isChecked() == true) {
                            a35.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a35);
                        }
                        if (a41.isChecked() == true) {
                            a41.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a41);
                        }
                        if (a42.isChecked() == true) {
                            a42.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a42);
                        }
                        if (a43.isChecked() == true) {
                            a43.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a43);
                        }
                        if (a44.isChecked() == true) {
                            a44.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a44);
                        }
                        if (a45.isChecked() == true) {
                            a45.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(a45);
                        }





                    }
                }
                else{
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragment_container,new PLogin());
                    transaction.commit();
                }
            }
        });
        return v;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

    }
}

//    private RecyclerView recyclerView;
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View v= inflater.inflate(R.layout.bus_a, container, false);
//        recyclerView=v.findViewById(R.id.event_list_recyclerview);
//        Button book = v.findViewById(R.id.book);
//        final CheckBox a11 = v.findViewById(R.id.A11);
//        final CheckBox a12 = v.findViewById(R.id.A12);
//        final CheckBox a13 = v.findViewById(R.id.A13);
//        final CheckBox a14 = v.findViewById(R.id.A14);
//        final CheckBox a15 = v.findViewById(R.id.A15);
//        final CheckBox a21 = v.findViewById(R.id.A21);
//        final CheckBox a22 = v.findViewById(R.id.A22);
//        final CheckBox a23 = v.findViewById(R.id.A23);
//        final CheckBox a24 = v.findViewById(R.id.A24);
//        final CheckBox a25 = v.findViewById(R.id.A25);
//        final CheckBox a31 = v.findViewById(R.id.A31);
//        final CheckBox a32 = v.findViewById(R.id.A32);
//        final CheckBox a33 = v.findViewById(R.id.A33);
//        final CheckBox a34 = v.findViewById(R.id.A34);
//        final CheckBox a35 = v.findViewById(R.id.A35);
//        final CheckBox a41 = v.findViewById(R.id.A41);
//        final CheckBox a42 = v.findViewById(R.id.A42);
//        final CheckBox a43 = v.findViewById(R.id.A43);
//        final CheckBox a44 = v.findViewById(R.id.A44);
//        final CheckBox a45 = v.findViewById(R.id.A45);
//
//
//
//        book.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(a11.isChecked() == false || a12.isChecked() == false || a13.isChecked() == false || a14.isChecked() == false || a15.isChecked() == false || a21.isChecked() == false ||
//                a22.isChecked() == false || a23.isChecked() == false || a24.isChecked() == false || a25.isChecked() == false || a31.isChecked() == false || a32.isChecked() == false ||
//                a33.isChecked() == false || a34.isChecked() == false || a35.isChecked() == false || a41.isChecked() == false || a42.isChecked() == false || a43.isChecked() == false || a44.isChecked() == false || a45.isChecked() == false) {
//                    Toast.makeText(getActivity(),"please select a seats",Toast.LENGTH_SHORT).show();
//                }else{
//
//                }
//            }
//        });
//        return v;
//    }
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState){
//        super.onCreate(savedInstanceState);
//
//    }
//}
