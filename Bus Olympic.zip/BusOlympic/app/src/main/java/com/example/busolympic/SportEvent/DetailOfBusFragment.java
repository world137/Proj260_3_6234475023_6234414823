package com.example.busolympic.SportEvent;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.busolympic.Bookingfragment;
import com.example.busolympic.BusEvents.BusTimeTableHome;
import com.example.busolympic.BusEvents.SecondMainActivity;
import com.example.busolympic.Profilefragment;
import com.example.busolympic.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DetailOfBusFragment extends AppCompatActivity {

    public static final String EXTRA_SPORTS_EVENT="extra sport events";

    private TextView header,venue,date,startTime,duration,travel;
    private ImageView image , back ,book;
    public String bus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_of_bus);
        back=findViewById(R.id.back);
        header=findViewById(R.id.TV_event_header);
        venue=findViewById(R.id.TV_place);
        date=findViewById(R.id.TV_date);
        startTime=findViewById(R.id.TV_startTime);
        duration=findViewById(R.id.TV_duration);
        travel=findViewById(R.id.TV_time_travel);
        bus = venue.toString();
        book=findViewById(R.id.book);

        SportsDetail sportsDetail=getIntent().getParcelableExtra(EXTRA_SPORTS_EVENT);


        header.setText(sportsDetail.getSportName());
        venue.setText("Venue: "+sportsDetail.getEventVenue());
        date.setText("Date: "+sportsDetail.getEventDate());
        startTime.setText("Start:"+sportsDetail.getEventStartTime());
        duration.setText("Duration: "+sportsDetail.getEventDuration());
        travel.setText("Travel by bus: "+sportsDetail.getEventBusTravelTime());
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailOfBusFragment.this, SecondMainActivity.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bnv = findViewById(R.id.bottom_menu_bar);
        bnv.setOnNavigationItemSelectedListener(navListener);

    }
    public String getVenue(){
        return bus;
    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener= new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment = null;
            switch(item.getItemId()){
                case R.id.nav_home:
                    selectedFragment = new BusTimeTableHome();
                    break;

                case R.id.nav_booking:
                    selectedFragment = new Bookingfragment();
                    break;

                case R.id.nav_profile:
                    selectedFragment = new Profilefragment();
                    break;
            }
            return true;
        }
    };

}