package com.example.busolympic.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.busolympic.Bookingfragment;
import com.example.busolympic.BusEvents.BusTimeTableHome;
import com.example.busolympic.Profilefragment;
import com.example.busolympic.R;
import com.example.busolympic.SportEvent.SportsEventHome;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class PRegister extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_p_register, container, false);
        ImageView registerButton = view.findViewById(R.id.register);
        ImageView back = view.findViewById(R.id.back);
        final EditText userInput = (EditText) view.findViewById(R.id.username);
        final EditText passwordInput = (EditText) view.findViewById(R.id.password);
        final EditText password2Input = (EditText) view.findViewById(R.id.password2);
        final EditText emailInput = (EditText) view.findViewById(R.id.email);
        final EditText cardNumberInput = (EditText) view.findViewById(R.id.idCard);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userID = userInput.getText().toString();
                String password = passwordInput.getText().toString();
                String password2 = password2Input.getText().toString();
                String cardNumber = cardNumberInput.getText().toString();
                String email = emailInput.getText().toString();
                if (userID.length() == 0) {
                    Toast.makeText(getActivity(), "Please enter username", Toast.LENGTH_SHORT).show();
//                }else if(userID.){
                    // เช็คตัวพิมพ์ใหญ่
                } else if (email.length() == 0) {
                    Toast.makeText(getActivity(), "Please enter email", Toast.LENGTH_SHORT).show();
                } else if (cardNumber.length() == 0) {
                    Toast.makeText(getActivity(), "Please enter card number", Toast.LENGTH_SHORT).show();
                } else if (password.length() == 0) {
                    Toast.makeText(getActivity(), "Please enter password", Toast.LENGTH_SHORT).show();
                }else if(password.length() < 8){
                    Toast.makeText(getActivity(),"Password must be at least 8 characters",Toast.LENGTH_SHORT).show();
                }else if(password2.length() == 0){
                    Toast.makeText(getActivity(),"Please confirm password",Toast.LENGTH_SHORT).show();
                } else if (password.equals(password2) == false) {
                    Toast.makeText(getActivity(), "Password does not match", Toast.LENGTH_SHORT).show();
                } else {
                    Profile newProfile = new Profile(userID, password, cardNumber);
                    Method.addNewUserAccount(getContext(), newProfile);
                    Method.saveLoginStatus(getContext(), true);
                    Fragment newFragment = new Profilefragment();
                    Toast.makeText(getActivity(), "Signup Successful", Toast.LENGTH_SHORT).show();
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragment_container, newFragment);
                    transaction.commit();
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Method.saveLoginStatus(getContext(), false);
                Fragment newFragment = new Profilefragment();
                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, newFragment);
                transaction.commit();
            }
        });

        return view;

    }

}