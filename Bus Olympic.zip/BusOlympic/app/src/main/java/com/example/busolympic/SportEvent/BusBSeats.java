package com.example.busolympic.SportEvent;

import android.app.AlertDialog;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.busolympic.BusEvents.BusDetail;
import com.example.busolympic.R;
import com.example.busolympic.profile.Method;
import com.example.busolympic.profile.PLogin;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class BusBSeats extends Fragment {
    @Nullable
    public int ischeckbox(CheckBox x) {
        int y = 0;
        if (x.isChecked()) {
            y++;
        }
        return y;
    }

    public int isover(ArrayList<CheckBox> x) {
        int y = 0;
        for (CheckBox a : x) {
            y += ischeckbox(a);
        }
        return y;
    }

    private RecyclerView recyclerView;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.bus_b, container, false);
        recyclerView = v.findViewById(R.id.event_list_recyclerview);
        Button book = v.findViewById(R.id.book);
        final CheckBox b11 = v.findViewById(R.id.B11);
        final CheckBox b12 = v.findViewById(R.id.B12);
        final CheckBox b13 = v.findViewById(R.id.B13);
        final CheckBox b14 = v.findViewById(R.id.B14);
        final CheckBox b15 = v.findViewById(R.id.B15);
        final CheckBox b21 = v.findViewById(R.id.B21);
        final CheckBox b22 = v.findViewById(R.id.B22);
        final CheckBox b23 = v.findViewById(R.id.B23);
        final CheckBox b24 = v.findViewById(R.id.B24);
        final CheckBox b25 = v.findViewById(R.id.B25);
        final ArrayList<CheckBox> seat = new ArrayList<CheckBox>();
        final ArrayList<CheckBox> yourseat = new ArrayList<CheckBox>();
        seat.add(b11);
        seat.add(b12);
        seat.add(b13);
        seat.add(b14);
        seat.add(b15);
        seat.add(b21);
        seat.add(b22);
        seat.add(b23);
        seat.add(b24);
        seat.add(b25);

        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileInputStream fis = null;
                String output = "";
                Context context = null;

                try {
                    fis = context.openFileInput("IsLogintxt");
                    InputStreamReader isr = new InputStreamReader(fis);
                    BufferedReader br = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    String text;

                    while ((text = br.readLine()) != null) {
                        sb.append(text);
                    }

                    output = sb.toString();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (fis != null) {
                        try {
                            fis.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (output == "true") {
                    if (b11.isChecked() == false || b12.isChecked() == false || b13.isChecked() == false || b14.isChecked() == false || b15.isChecked() == false || b21.isChecked() == false ||
                            b22.isChecked() == false || b23.isChecked() == false || b24.isChecked() == false || b25.isChecked() == false) {
                        Toast.makeText(getActivity(), "please select a seats", Toast.LENGTH_SHORT).show();
                    } else if (isover(seat) > 2) {
                        Toast.makeText(getActivity(), "over booking", Toast.LENGTH_SHORT).show();
                    } else {
                        if (b11.isChecked() == true) {
                            b11.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b11);
                        }
                        if (b12.isChecked() == true) {
                            b12.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b12);
                        }
                        if (b13.isChecked() == true) {
                            b13.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b13);
                        }
                        if (b14.isChecked() == true) {
                            b14.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b14);
                        }
                        if (b15.isChecked() == true) {
                            b15.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b15);
                        }
                        if (b21.isChecked() == true) {
                            b21.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b21);
                        }
                        if (b22.isChecked() == true) {
                            b22.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b22);
                        }
                        if (b23.isChecked() == true) {
                            b23.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b23);
                        }
                        if (b24.isChecked() == true) {
                            b24.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b24);
                        }
                        if (b25.isChecked() == true) {
                            b25.setBackground(Drawable.createFromPath("redchair"));
                            yourseat.add(b25);
                        }


                    }
                } else {
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragment_container, new PLogin());
                    transaction.commit();
                }
            }
        });
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}
//    public static String loadLoginStatus(Context context) {
//        FileInputStream fis = null;
//        String output = "";
//
//        try {
//            fis = context.openFileInput("IsLogintxt");
//            InputStreamReader isr = new InputStreamReader(fis);
//            BufferedReader br = new BufferedReader(isr);
//            StringBuilder sb = new StringBuilder();
//            String text;
//
//            while ((text = br.readLine()) != null) {
//                sb.append(text);
//            }
//
//            output = sb.toString();
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            if (fis != null) {
//                try {
//                    fis.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//        return output;
//    }
//}

//    private RecyclerView recyclerView;
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View v= inflater.inflate(R.layout.bus_a, container, false);
//        recyclerView=v.findViewById(R.id.event_list_recyclerview);
//        Button book = v.findViewById(R.id.book);
//        final CheckBox a11 = v.findViewById(R.id.A11);
//        final CheckBox a12 = v.findViewById(R.id.A12);
//        final CheckBox a13 = v.findViewById(R.id.A13);
//        final CheckBox a14 = v.findViewById(R.id.A14);
//        final CheckBox a15 = v.findViewById(R.id.A15);
//        final CheckBox a21 = v.findViewById(R.id.A21);
//        final CheckBox a22 = v.findViewById(R.id.A22);
//        final CheckBox a23 = v.findViewById(R.id.A23);
//        final CheckBox a24 = v.findViewById(R.id.A24);
//        final CheckBox a25 = v.findViewById(R.id.A25);
//        final CheckBox a31 = v.findViewById(R.id.A31);
//        final CheckBox a32 = v.findViewById(R.id.A32);
//        final CheckBox a33 = v.findViewById(R.id.A33);
//        final CheckBox a34 = v.findViewById(R.id.A34);
//        final CheckBox a35 = v.findViewById(R.id.A35);
//        final CheckBox a41 = v.findViewById(R.id.A41);
//        final CheckBox a42 = v.findViewById(R.id.A42);
//        final CheckBox a43 = v.findViewById(R.id.A43);
//        final CheckBox a44 = v.findViewById(R.id.A44);
//        final CheckBox a45 = v.findViewById(R.id.A45);
//
//
//
//        book.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(a11.isChecked() == false || a12.isChecked() == false || a13.isChecked() == false || a14.isChecked() == false || a15.isChecked() == false || a21.isChecked() == false ||
//                        a22.isChecked() == false || a23.isChecked() == false || a24.isChecked() == false || a25.isChecked() == false){
//                    Toast.makeText(getActivity(),"please select a seats",Toast.LENGTH_SHORT).show();
//                }else{
//
//                }
//            }
//        });
//        return v;
//    }
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState){
//        super.onCreate(savedInstanceState);
//
//    }
//}
