package com.example.busolympic.profile;
import java.io.Serializable;
import java.util.ArrayList;
public class user {
    private boolean isLogin = false;
    private ArrayList<Profile> profilesList;

    public user() {
        profilesList = new ArrayList<Profile>();
    }

    public void addProfile(Profile profile) {
        profilesList.add(profile);
    }

    public ArrayList<Profile> getProfilesList() {
        return profilesList;
    }

    public boolean isInUsers(Profile profile) {
        for (Profile profileSearch : profilesList) {
            if (profileSearch.equals(profile)) {
                return true;
            }
        }
        return false;
    }

    public int getIndex(Profile profile) {
        for (int i = 0; i < profilesList.size(); i++) {
            if (profile.equals(profilesList.get(i))) {
                return i;
            }
        }
        return 0;
    }

}

