package com.example.busolympic.BusEvents;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.busolympic.R;

public class DetailOfSeats extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_of_seats);
    }
}
